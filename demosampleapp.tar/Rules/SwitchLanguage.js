/**
 * Describe this function...
 * @param {IClientAPI} clientAPI
 */
export default async function SwitchLanguage(clientAPI) {
    let language = clientAPI.localizeText('Language') === 'EN' ? 'fi' : 'en'; // Toggle language

    // Switch Language Action
    await clientAPI.getPageProxy().executeAction({
        "Name": language === 'fi' ? "/demosampleapp/Actions/LanguageSwitchFI.action" : "/demosampleapp/Actions/LanguageSwitchEN.action"
    });

    // Redraw the page to apply the language change
    clientAPI.getPageProxy().redraw();
}
