sap.ui.define([
	"sapbasictemplate/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
