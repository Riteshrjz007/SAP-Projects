/* global QUnit */

sap.ui.require(["sapbasictemplate/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
